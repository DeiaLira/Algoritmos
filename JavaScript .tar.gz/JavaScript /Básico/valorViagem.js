let preçoCombustivel = 6;
const gastoCombustivelKM = 10;
let distanciaTotalKM = 100;

let quantidadeLitros = (distanciaTotalKM/gastoCombustivelKM);
let valorTotalViagem = (quantidadeLitros*preçoCombustivel);

console.log(`O valor total a ser gasto é ${valorTotalViagem.toFixed(2)} reais.`);