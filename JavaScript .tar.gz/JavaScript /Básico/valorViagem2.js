let precoEtanol = 5.79;
let precoGasolina = 6.66;
let tipoCombustivel = 'gasolina';
const gastoCombustivelKM = 10;
let distanciaTotalKM = 100;

let quantidadeLitros = (distanciaTotalKM/gastoCombustivelKM);

if (tipoCombustivel === 'gasolina') {
    let valorTotalViagem = (quantidadeLitros*precoGasolina);
    console.log(`O valor total a ser gasto é ${valorTotalViagem.toFixed(2)} reais, usando gasolina.`);
 } else if (tipoCombustivel === 'etanol') {
    let valorTotalViagem = (quantidadeLitros*precoEtanol);
    console.log(`O valor total a ser gasto é ${valorTotalViagem.toFixed(2)} reais, usando etanol.`);
} else {
    console.log (`Informação inválida`);
}