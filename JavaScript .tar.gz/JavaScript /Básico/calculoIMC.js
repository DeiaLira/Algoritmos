let pesoUsuario = 63;
let alturaUsuario = 1.75;

let imcUsuario = pesoUsuario / (Math.pow(alturaUsuario,2));

if (imcUsuario < 18.5) {
    console.log (`Seu IMC é ${imcUsuario.toFixed(2)}. Você está abaixo do peso ideal!`)
} else if (imcUsuario >= 18.5 && imcUsuario <= 25) {
    console.log (`Seu IMC é ${imcUsuario.toFixed(2)}. Você está com o peso ideal!`)
} else if (imcUsuario >= 25 && imcUsuario <= 30) {
    console.log (`Seu IMC é ${imcUsuario.toFixed(2)}. Você está acima do peso!`)
} else if (imcUsuario >= 30 && imcUsuario <= 40) {
    console.log (`Seu IMC é ${imcUsuario.toFixed(2)}. Você está obeso!`)
} else {
    console.log (`Seu IMC é ${imcUsuario.toFixed(2)}. Você está com obesidade grave!`)
}