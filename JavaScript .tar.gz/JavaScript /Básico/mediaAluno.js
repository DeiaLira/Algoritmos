let nota01 = 5;
let nota02 = 3;
let nota03 = 7;

let mediaAluno = (nota01 + nota02 + nota03) / 3;

if (mediaAluno < 5) {
  console.log(`Sua média foi ${mediaAluno}, logo está reprovado!`);
} else if (mediaAluno >= 5 && mediaAluno <= 7) {
  console.log(`Sua média foi ${mediaAluno}, logo está em recuperação!`);
} else {
  console.log(`Sua média foi ${mediaAluno}, parabéns pela aprovação!`);
}
