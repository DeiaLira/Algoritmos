let valorEtiquetaProduto = 100;
let formaPagamento = 'outro';

if (formaPagamento === 'Débito') {
    let valorFinalProduto = valorEtiquetaProduto - ((10/100) * valorEtiquetaProduto);
    console.log(`O valor final do produto é R$ ${valorFinalProduto}.`);
} else if (formaPagamento === 'Dinheiro ou PIX') {
    let valorFinalProduto = valorEtiquetaProduto - ((15/100) * valorEtiquetaProduto);
    console.log(`O valor final do produto é R$ ${valorFinalProduto}.`);
} else if (formaPagamento === 'Em duas vezes') {
    console.log(`O valor final do produto é R$ ${valorEtiquetaProduto}.`);
} else {
    let valorFinalProduto = valorEtiquetaProduto + ((10/100) * valorEtiquetaProduto);
    console.log(`O valor final do produto é R$ ${valorFinalProduto}.`);
}