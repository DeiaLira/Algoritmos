function calcularValor(valorEtiquetaProduto, formaPagamento) {
    if (formaPagamento === 'Débito') {
        let valorFinalProduto = valorEtiquetaProduto - ((10/100) * valorEtiquetaProduto);
        return (`O valor final do produto é R$ ${valorFinalProduto}.`);
    } else if (formaPagamento === 'Dinheiro ou PIX') {
        let valorFinalProduto = valorEtiquetaProduto - ((15/100) * valorEtiquetaProduto);
        return (`O valor final do produto é R$ ${valorFinalProduto}.`);
    } else if (formaPagamento === 'Em duas vezes') {
        return (`O valor final do produto é R$ ${valorEtiquetaProduto}.`);
    } else {
        let valorFinalProduto = valorEtiquetaProduto + ((10/100) * valorEtiquetaProduto);
        return (`O valor final do produto é R$ ${valorFinalProduto}.`);
    }
}

(function () {
let valorEtiquetaProduto = 250;
let formaPagamento = 'Dinheiro ou PIX';

console.log(calcularValor(valorEtiquetaProduto, formaPagamento));

})();


