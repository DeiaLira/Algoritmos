function calculoIMC(pesoUsuario, alturaUsuario) {
    return pesoUsuario / (Math.pow(alturaUsuario,2));
}

function classificarIMC(imcUsuario) {
    if (imcUsuario < 18.5) {
        return (`Seu IMC é ${imcUsuario.toFixed(2)}. Você está abaixo do peso ideal!`)
    } else if (imcUsuario >= 18.5 && imcUsuario <= 25) {
        return (`Seu IMC é ${imcUsuario.toFixed(2)}. Você está com o peso ideal!`)
    } else if (imcUsuario >= 25 && imcUsuario <= 30) {
        return (`Seu IMC é ${imcUsuario.toFixed(2)}. Você está acima do peso!`)
    } else if (imcUsuario >= 30 && imcUsuario <= 40) {
        return (`Seu IMC é ${imcUsuario.toFixed(2)}. Você está obeso!`)
    } else {
        return (`Seu IMC é ${imcUsuario.toFixed(2)}. Você está com obesidade grave!`)
    }
}

//Main
(function () {

let pesoUsuario = 63;
let alturaUsuario = 1.75;

let imcUsuario = calculoIMC(pesoUsuario, alturaUsuario);
console.log(classificarIMC(imcUsuario));

})();

