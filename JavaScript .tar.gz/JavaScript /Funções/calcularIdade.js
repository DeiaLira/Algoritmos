function classificarIdade(idade) {
    if (idade <= 18) {
        return (`Sua idade é ${idade}, logo você é menor de idade!`)
    } else {
        return (`Sua idade é ${idade}, logo você é maior de idade!`)
    }
}

(function () {
    let idadeUsuario = 12;
    console.log(classificarIdade(idadeUsuario));
}
)();