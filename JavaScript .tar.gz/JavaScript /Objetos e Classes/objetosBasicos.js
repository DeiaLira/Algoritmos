const pessoa = {
    nome: 'Andreia',
    idade: 22,
    cidade: 'iguatu',

    descrever: function () {
        console.log(`Meu nome é ${this.nome}, tenho ${this.idade} anos e moro na cidade de ${this.cidade}`)
    }
}

//pessoa.descrever();
const atributo = 'idade';
console.log(pessoa[atributo]);