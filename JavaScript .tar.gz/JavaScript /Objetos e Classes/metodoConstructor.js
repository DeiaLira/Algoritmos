class Pessoa {
    nome;
    idade;

    constructor(nome, idade) {
        this.nome = nome;
        this.idade = idade;
    }

    descrever() {
        console.log(`Meu nome é ${this.nome} e eu tenho ${this.idade} anos.`);
    }
}

const andreia = new Pessoa('Andreia', 22);
const joana = new Pessoa('Joana', 23);

console.log(andreia.descrever());
console.log(joana.descrever());