class Pessoa {
    nome;
    peso;
    altura;

    constructor(nome, peso, altura) {
        this.nome = nome;
        this.peso = peso;
        this.altura = altura;
    }

    calcularIMC() {
        let valorIMC =  this.peso / (Math.pow(this.altura,2));
        return valorIMC.toFixed(2);
    }
}

(function() {
    const andreia = new Pessoa('Andreia', 75, 1.64);
    const jose = new Pessoa('Jose', 70, 1.75);

    console.log(jose.classificarIMC());
})();