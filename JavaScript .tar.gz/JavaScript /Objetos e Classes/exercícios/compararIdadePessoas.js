class Pessoa {
    nome;
    idade;
    cidade;

    constructor(nome, idade, cidade) {
         this.nome = nome;
         this.idade = idade;
         this.cidade = cidade;
    }

    descrever() {
        console.log(`Meu nome é ${this.nome}, tenho ${this.idade} anos e moro em ${this.cidade}`);
    }
}

function compararIdades(user1, user2) {
    if (user1.idade > user2.idade) {
        console.log(`${user1.nome} é mais velhor que ${user2.nome}`);
    } else if (user1.idade < user2.idade){
        console.log(`${user2.nome} é mais velhor que ${user1.nome}`);
    } else {
        console.log(`${user1.nome} e ${user2.nome} têm a mesma idade!`);
    }
}

(function main(){
    const andreia = new Pessoa('Andreia', 23, 'Iguatu');
    const joana = new Pessoa('Joana', 23, 'Fortaleza');

    console.log(compararIdades(andreia, joana));
})();