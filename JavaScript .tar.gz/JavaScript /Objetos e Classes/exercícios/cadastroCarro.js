class Carro {
    modelo;
    marca;
    cor;
    gastoMedioCombustivel;

    constructor(modelo, marca, cor, gastoMedioCombustivel) {
        this.modelo = modelo;
        this.marca = marca;
        this.cor = cor;
        this.gastoMedioCombustivel = gastoMedioCombustivel;
    }

    gastoCombustivelReais(precoCombustivel, distanciaTotalKM) {
        let quantidadeCombustivelLitros = (distanciaTotalKM/this.gastoMedioCombustivel);
        let valorTotalViagem = (quantidadeCombustivelLitros*precoCombustivel);

        console.log(`Para fazer uma viagem de ${distanciaTotalKM} Km, em um ${this.modelo}, você gastará aproximadamente R$ ${valorTotalViagem.toFixed(2)}.`)
    }
}

(function main() {
    const corsa = new Carro('Corsa', 'Chevrolet', 'Vermelho', 10);
    let distanciaTotalKM = 100;
    let precoCombustivel = 6;
    
    console.log(corsa.gastoCombustivelReais(precoCombustivel, distanciaTotalKM));
})();