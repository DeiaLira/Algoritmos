class Pessoa {
    nome;
    idade;

    descrever() {
        console.log(`Meu nome é ${this.nome} e eu tenho ${this.idade} anos.`);
    }
}

const andreia = new Pessoa();
const joana = new Pessoa();

andreia.nome = 'Andreia';
andreia.idade = 22;

joana.nome = 'Joana';
joana.idade = 23;


console.log(andreia.descrever());
console.log(joana.descrever());